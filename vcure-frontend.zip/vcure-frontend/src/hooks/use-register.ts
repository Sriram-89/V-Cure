import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { authService } from "@/services/auth-service";
import { useAuthStore } from "@/store/auth-store";
import { ROUTES } from "@/constants/routes";
import { ApiError } from "@/lib/api-client";
import type { RegisterRequestDto } from "@/types/auth";

export function useRegister() {
  const router = useRouter();
  const setSession = useAuthStore((state) => state.setSession);

  return useMutation({
    mutationFn: (payload: RegisterRequestDto) => authService.register(payload),
    onSuccess: (data) => {
      setSession(data.user, data.tokens.accessToken, data.tokens.refreshToken);
      router.push(ROUTES.ONBOARDING);
    }
  });
}

export function getRegisterErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.statusCode === 409) {
      return "An account with this email already exists.";
    }
    return error.message;
  }
  return "Something went wrong. Please try again.";
}
