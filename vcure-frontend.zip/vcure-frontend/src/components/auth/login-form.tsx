"use client";

import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AlertCircle } from "lucide-react";
import { InputField } from "@/components/ui/input-field";
import { Button } from "@/components/ui/button";
import { loginSchema, type LoginFormValues } from "@/lib/validation/auth";
import { useLogin, getLoginErrorMessage } from "@/hooks/use-login";
import { ROUTES } from "@/constants/routes";

export function LoginForm() {
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema)
  });

  const loginMutation = useLogin();

  const onSubmit = (values: LoginFormValues) => {
    loginMutation.mutate(values);
  };

  return (
    <form className="flex flex-col gap-5" onSubmit={handleSubmit(onSubmit)} noValidate>
      {loginMutation.isError ? (
        <div
          role="alert"
          className="flex items-start gap-2 rounded-md border border-danger/20 bg-red-50 p-3 text-sm text-danger"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          {getLoginErrorMessage(loginMutation.error)}
        </div>
      ) : null}

      <InputField
        label="Email"
        type="email"
        autoComplete="email"
        error={errors.email?.message}
        {...register("email")}
      />

      <InputField
        label="Password"
        type="password"
        autoComplete="current-password"
        error={errors.password?.message}
        {...register("password")}
      />

      <div className="flex justify-end">
        <Link
          href={ROUTES.FORGOT_PASSWORD}
          className="text-sm font-medium text-primary hover:text-primary-700"
        >
          Forgot password?
        </Link>
      </div>

      <Button type="submit" className="w-full" isLoading={loginMutation.isPending}>
        Log in
      </Button>

      <p className="text-center text-sm text-text-secondary">
        Don&apos;t have an account?{" "}
        <Link href={ROUTES.REGISTER} className="font-medium text-primary hover:text-primary-700">
          Sign up
        </Link>
      </p>
    </form>
  );
}
