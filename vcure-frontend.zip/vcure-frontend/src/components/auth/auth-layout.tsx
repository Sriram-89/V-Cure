import Link from "next/link";
import { HeartPulse, ShieldCheck } from "lucide-react";
import { ROUTES } from "@/constants/routes";

export function AuthLayout({
  title,
  subtitle,
  children
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <div className="flex flex-col justify-center px-4 py-12 sm:px-6 lg:px-16">
        <div className="mx-auto w-full max-w-sm">
          <Link href={ROUTES.HOME} className="flex items-center gap-2 font-semibold">
            <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-white">
              <HeartPulse className="h-4 w-4" aria-hidden="true" />
            </span>
            V-Cure
          </Link>

          <h1 className="mt-8 text-2xl font-semibold tracking-tight text-text-primary">
            {title}
          </h1>
          <p className="mt-2 text-sm text-text-secondary">{subtitle}</p>

          <div className="mt-8">{children}</div>
        </div>
      </div>

      <div className="hidden bg-surface-muted md:flex md:flex-col md:justify-center md:px-16">
        <div className="max-w-md">
          <span className="flex h-11 w-11 items-center justify-center rounded-md bg-primary-50 text-primary">
            <ShieldCheck className="h-5 w-5" aria-hidden="true" />
          </span>
          <p className="mt-6 text-lg font-medium text-text-primary">
            Every recommendation is checked against your allergies, conditions,
            and medications before you ever see it.
          </p>
        </div>
      </div>
    </div>
  );
}
