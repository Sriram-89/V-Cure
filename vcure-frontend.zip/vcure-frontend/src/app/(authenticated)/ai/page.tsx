"use client";

import { useEffect } from "react";
import { AlertCircle } from "lucide-react";
import { Container } from "@/components/ui/container";
import { ConversationSidebar } from "@/components/ai-chat/conversation-sidebar";
import { ChatMessageList } from "@/components/ai-chat/chat-message-list";
import { ChatInput } from "@/components/ai-chat/chat-input";
import { SuggestedQuestions } from "@/components/ai-chat/suggested-questions";
import { QuickPrompts } from "@/components/ai-chat/quick-prompts";
import { MedicalContextPanel } from "@/components/ai-chat/medical-context-panel";
import { NutritionContextPanel } from "@/components/ai-chat/nutrition-context-panel";
import {
  useConversations,
  useConversation,
  useCreateConversation,
  useSendMessage
} from "@/hooks/use-ai-chat";
import { useAiChatStore } from "@/store/ai-chat-store";

export default function AiChatPage() {
  const activeConversationId = useAiChatStore((state) => state.activeConversationId);
  const setActiveConversationId = useAiChatStore((state) => state.setActiveConversationId);
  const isStreaming = useAiChatStore((state) => state.isStreaming);
  const streamingText = useAiChatStore((state) => state.streamingText);

  const conversations = useConversations();
  const conversation = useConversation(activeConversationId);
  const createConversation = useCreateConversation();
  const sendMessage = useSendMessage(activeConversationId);

  // Auto-select the most recent conversation, or leave empty for the
  // "start a new conversation" empty state.
  useEffect(() => {
    if (!activeConversationId && conversations.data && conversations.data.length > 0) {
      setActiveConversationId(conversations.data[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversations.data]);

  const handleSend = (content: string) => {
    if (!activeConversationId) return;
    sendMessage.mutate(content);
  };

  const handleStartFromPrompt = (prompt: string) => {
    if (!activeConversationId) {
      createConversation.mutate(undefined, {
        onSuccess: () => sendMessage.mutate(prompt)
      });
      return;
    }
    sendMessage.mutate(prompt);
  };

  return (
    <Container className="max-w-6xl py-8">
      <h1 className="text-2xl font-semibold text-text-primary">AI Coach</h1>
      <p className="mt-1 text-sm text-text-secondary">
        Ask questions about your plan, meals, or medical profile.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[240px_1fr_280px]">
        <div className="hidden lg:block">
          <ConversationSidebar />
        </div>

        <div className="flex min-h-[60vh] flex-col rounded-card border border-border bg-surface p-6 shadow-card">
          {!activeConversationId ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center">
              <p className="text-sm text-text-secondary">
                Start a new conversation to talk with your AI Coach.
              </p>
              <button
                type="button"
                onClick={() => createConversation.mutate()}
                className="rounded-button bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-700"
              >
                New conversation
              </button>
            </div>
          ) : conversation.isLoading ? (
            <div className="flex-1 space-y-3">
              <div className="h-16 w-2/3 animate-pulse rounded-card bg-surface-muted" />
              <div className="ml-auto h-10 w-1/2 animate-pulse rounded-card bg-surface-muted" />
            </div>
          ) : conversation.isError || !conversation.data ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-2 text-center">
              <AlertCircle className="h-6 w-6 text-danger" aria-hidden="true" />
              <p className="text-sm text-danger">Couldn&apos;t load this conversation.</p>
            </div>
          ) : (
            <>
              <ChatMessageList
                messages={conversation.data.messages}
                isStreaming={isStreaming}
                streamingText={streamingText}
                onRetry={() => {
                  const lastUserMessage = [...conversation.data.messages]
                    .reverse()
                    .find((m) => m.role === "user");
                  if (lastUserMessage) sendMessage.mutate(lastUserMessage.content);
                }}
              />
              {conversation.data.messages.length === 0 ? (
                <SuggestedQuestions onSelect={handleStartFromPrompt} />
              ) : null}
              <ChatInput onSend={handleSend} disabled={isStreaming} />
            </>
          )}
        </div>

        <div className="hidden flex-col gap-6 lg:flex">
          <QuickPrompts onSelect={handleStartFromPrompt} />
          <MedicalContextPanel />
          <NutritionContextPanel />
        </div>
      </div>
    </Container>
  );
}
