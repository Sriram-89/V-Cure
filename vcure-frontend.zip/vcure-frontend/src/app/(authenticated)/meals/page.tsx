"use client";

import { Container } from "@/components/ui/container";
import { MealCalendar } from "@/components/meals/meal-calendar";
import { SlotTabs } from "@/components/meals/slot-tabs";
import { DailyPlanList } from "@/components/meals/daily-plan-list";
import { RecommendedMealsSection } from "@/components/meals/recommended-meals-section";
import { WaterRecommendationCard } from "@/components/meals/water-recommendation-card";
import { MealSearchSection } from "@/components/meals/meal-search-section";
import { FavoritesRecentTabs } from "@/components/meals/favorites-recent-tabs";
import { MealDetailsPanel } from "@/components/meals/meal-details-panel";
import { useMealPlannerStore } from "@/store/meal-planner-store";

export default function MealPlannerPage() {
  const selectedDate = useMealPlannerStore((state) => state.selectedDate);
  const setSelectedDate = useMealPlannerStore((state) => state.setSelectedDate);
  const activeSlot = useMealPlannerStore((state) => state.activeSlot);
  const setActiveSlot = useMealPlannerStore((state) => state.setActiveSlot);

  return (
    <Container className="max-w-5xl py-8">
      <h1 className="text-2xl font-semibold text-text-primary">Meal planner</h1>
      <p className="mt-1 text-sm text-text-secondary">
        Your plan, recommendations, and tracking — all screened by the safety layer.
      </p>

      <div className="mt-6">
        <MealCalendar selectedDate={selectedDate} onSelect={setSelectedDate} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="flex flex-col gap-6 lg:col-span-2">
          <div className="rounded-card border border-border bg-surface p-6 shadow-card">
            <SlotTabs activeSlot={activeSlot} onChange={setActiveSlot} />
            <div className="mt-4">
              <DailyPlanList slot={activeSlot} />
            </div>
          </div>

          <div className="rounded-card border border-border bg-surface p-6 shadow-card">
            <RecommendedMealsSection slot={activeSlot} />
          </div>

          <MealSearchSection />
        </div>

        <div className="flex flex-col gap-6">
          <WaterRecommendationCard />
          <FavoritesRecentTabs />
        </div>
      </div>

      <MealDetailsPanel />
    </Container>
  );
}
