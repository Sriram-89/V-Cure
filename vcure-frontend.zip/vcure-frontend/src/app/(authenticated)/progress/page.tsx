"use client";

import { Container } from "@/components/ui/container";
import { DateRangeSelector } from "@/components/progress/date-range-selector";
import { ProgressSummaryCards } from "@/components/progress/progress-summary-cards";
import { WeightChart } from "@/components/progress/weight-chart";
import { BmiChart } from "@/components/progress/bmi-chart";
import { CalorieChart } from "@/components/progress/calorie-chart";
import { WaterProgress } from "@/components/progress/water-progress";
import { NutritionProgressChart } from "@/components/progress/nutrition-progress-chart";
import { HealthScoreChart } from "@/components/progress/health-score-chart";
import { MealTrackingSummary } from "@/components/progress/meal-tracking-summary";
import { GoalProgressCard } from "@/components/progress/goal-progress-card";
import { MilestonesList } from "@/components/progress/milestones-list";
import { TrendAnalysisCard } from "@/components/progress/trend-analysis-card";
import { useProgressStore } from "@/store/progress-store";

export default function ProgressPage() {
  const range = useProgressStore((state) => state.range);
  const setRange = useProgressStore((state) => state.setRange);

  return (
    <Container className="max-w-5xl py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-text-primary">Progress</h1>
          <p className="mt-1 text-sm text-text-secondary">
            Track weight, nutrition, and habits over time.
          </p>
        </div>
        <DateRangeSelector range={range} onChange={setRange} />
      </div>

      <div className="mt-6">
        <ProgressSummaryCards />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <WeightChart range={range} />
        <BmiChart range={range} />
        <CalorieChart range={range} />
        <HealthScoreChart range={range} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <NutritionProgressChart range={range} />
        </div>
        <WaterProgress range={range} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <MealTrackingSummary range={range} />
        <GoalProgressCard />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <TrendAnalysisCard />
        <MilestonesList />
      </div>
    </Container>
  );
}
