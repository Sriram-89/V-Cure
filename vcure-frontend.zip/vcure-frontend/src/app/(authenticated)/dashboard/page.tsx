"use client";

import { AlertCircle, Scale, ShieldAlert, Flame } from "lucide-react";
import { Container } from "@/components/ui/container";
import { Button } from "@/components/ui/button";
import { StatCard } from "@/components/dashboard/stat-card";
import { TodayPlanCard } from "@/components/dashboard/today-plan-card";
import { WeightTrendChart } from "@/components/dashboard/weight-trend-chart";
import { DashboardSkeleton } from "@/components/dashboard/dashboard-skeleton";
import { useDashboardSummary } from "@/hooks/use-dashboard";

const BMI_CATEGORY_LABELS: Record<string, string> = {
  UNDERWEIGHT: "Underweight",
  NORMAL: "Normal",
  OVERWEIGHT: "Overweight",
  OBESE: "Obese"
};

export default function DashboardPage() {
  const { data, isLoading, isError, refetch, isRefetching } = useDashboardSummary();

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  if (isError || !data) {
    return (
      <Container className="py-16">
        <div className="mx-auto flex max-w-md flex-col items-center gap-3 text-center">
          <AlertCircle className="h-8 w-8 text-danger" aria-hidden="true" />
          <p className="text-sm text-text-secondary">
            We couldn&apos;t load your dashboard right now.
          </p>
          <Button onClick={() => refetch()} isLoading={isRefetching}>
            Try again
          </Button>
        </div>
      </Container>
    );
  }

  return (
    <Container className="py-8">
      <h1 className="text-2xl font-semibold text-text-primary">
        Welcome back, {data.fullName.split(" ")[0]}
      </h1>
      <p className="mt-1 text-sm text-text-secondary">
        Here&apos;s where things stand today.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <StatCard
          label="BMI"
          value={data.bmi !== null ? data.bmi.toFixed(1) : "—"}
          hint={data.bmiCategory ? BMI_CATEGORY_LABELS[data.bmiCategory] : "Not enough data yet"}
          icon={Scale}
        />
        <StatCard
          label="Active risk flags"
          value={String(data.activeRiskFlags.length)}
          hint={data.activeRiskFlags[0] ?? "Nothing flagged"}
          icon={ShieldAlert}
          tone="secondary"
        />
        <StatCard
          label="Current streak"
          value={`${data.streakDays} ${data.streakDays === 1 ? "day" : "days"}`}
          hint="Days you've logged a meal"
          icon={Flame}
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <TodayPlanCard meals={data.todayMeals} />
        <WeightTrendChart data={data.weightTrend} />
      </div>
    </Container>
  );
}
