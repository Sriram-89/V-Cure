import type { Metadata } from "next";
import { Container } from "@/components/ui/container";
import { ProfileCompletionSummary } from "@/components/profile/profile-completion-summary";
import { UserProfileSection } from "@/components/profile/user-profile-section";
import { HealthProfileSection } from "@/components/profile/health-profile-section";
import { LifestyleSection } from "@/components/profile/lifestyle-section";
import { GoalsSection } from "@/components/profile/goals-section";
import { ConditionsSection } from "@/components/profile/conditions-section";
import { AllergiesSection } from "@/components/profile/allergies-section";
import { MedicinesSection } from "@/components/profile/medicines-section";
import { FamilyHistorySection } from "@/components/profile/family-history-section";
import { DeleteAccountSection } from "@/components/profile/delete-account-section";

export const metadata: Metadata = { title: "Profile" };

export default function ProfilePage() {
  return (
    <Container className="max-w-3xl py-8">
      <h1 className="text-2xl font-semibold text-text-primary">Your profile</h1>
      <p className="mt-1 text-sm text-text-secondary">
        Everything here feeds directly into your plan and the safety layer.
      </p>

      <div className="mt-6 flex flex-col gap-6">
        <ProfileCompletionSummary />
        <UserProfileSection />
        <HealthProfileSection />

        <div>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wide text-text-secondary">
            Medical history
          </h2>
          <div className="flex flex-col gap-6">
            <ConditionsSection />
            <AllergiesSection />
            <MedicinesSection />
            <FamilyHistorySection />
          </div>
        </div>

        <LifestyleSection />
        <GoalsSection />

        <div>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wide text-text-secondary">
            Danger zone
          </h2>
          <DeleteAccountSection />
        </div>
      </div>
    </Container>
  );
}
