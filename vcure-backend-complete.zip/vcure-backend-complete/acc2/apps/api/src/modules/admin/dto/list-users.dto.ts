import { RoleType } from '@prisma/client';
import { Type } from 'class-transformer';
import { IsEnum, IsInt, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';
import { Role, AccountStatus } from '@prisma/client';

/**
 * API 67 query contract. The Bible documents exactly "Supports: Search,
 * Pagination, Filters"; ACC1's `AdminUserFilters` supplies the concrete field
 * names: query, role, status, page, pageSize.
 *
 * CONFLICT-3 is resolved: `status` filters on the canonical `User.status`
 * column. No filter beyond query/role/status/page/pageSize was invented.
 */
export class ListUsersDto {
  @IsOptional()
  @IsString()
  @MaxLength(120)
  query?: string;

  @IsOptional()
  @IsEnum(RoleType)
  role?: RoleType;

  @IsOptional()
  @IsEnum(AccountStatus)
  status?: AccountStatus;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page: number = 1;

  /** Upper bound enforced so a listing API can never return unbounded rows (03 §57). */
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  pageSize: number = 20;
}
