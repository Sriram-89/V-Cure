import { DietType } from '@prisma/client';
import {
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
} from 'class-validator';
import {
  AlcoholConsumption,
  SleepQuality,
  SmokingStatus,
  StressLevel,
} from '@prisma/client';

export class CreateLifestyleAssessmentDto {
  /** ACC1 contract: LifestyleProfileDto.dietType */
  @IsOptional()
  @IsEnum(DietType)
  dietType?: DietType;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(24)
  workingHoursPerDay?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(24)
  sleepHoursAvg?: number;

  @IsOptional()
  @IsEnum(SleepQuality)
  sleepQuality?: SleepQuality;

  @IsOptional()
  @IsEnum(StressLevel)
  stressLevel?: StressLevel;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(15)
  waterIntakeLitersAvg?: number;

  @IsOptional()
  @IsEnum(SmokingStatus)
  smokingStatus?: SmokingStatus;

  @IsOptional()
  @IsEnum(AlcoholConsumption)
  alcoholConsumption?: AlcoholConsumption;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(21)
  exerciseFrequencyPerWeek?: number;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  mealTimingNotes?: string;
}
