import { Type } from 'class-transformer';
import {
  IsArray, IsDateString, IsEnum, IsInt, IsNumber, IsOptional, IsString,
  Length, Max, Min, ValidateNested,
} from 'class-validator';
import {
  ActivityLevel, AlcoholConsumption, BloodGroup, DietType, Gender,
  GoalTimeline, PrimaryGoal, SmokingStatus,
} from '@prisma/client';

/** Mirrors ACC1 `PersonalInfoDto`. Note: ACC1 does NOT send fullName — see CONFLICT-1. */
export class PersonalInfoDto {
  @IsDateString() dateOfBirth!: string;
  @IsEnum(Gender) gender!: Gender;
  @IsString() @Length(7, 20) phone!: string;
}

export class OnboardingHealthProfileDto {
  @IsNumber() @Min(50) @Max(260) heightCm!: number;
  @IsNumber() @Min(20) @Max(400) weightKg!: number;
  @IsEnum(BloodGroup) bloodGroup!: BloodGroup;
}

export class OnboardingMedicalProfileDto {
  @IsArray() @IsString({ each: true }) conditions!: string[];
  @IsArray() @IsString({ each: true }) allergies!: string[];
  @IsArray() @IsString({ each: true }) medications!: string[];
}

export class OnboardingLifestyleDto {
  @IsEnum(ActivityLevel) activityLevel!: ActivityLevel;
  @IsInt() @Min(0) @Max(24) sleepHours!: number;
  @IsEnum(SmokingStatus) smokingStatus!: SmokingStatus;
  @IsEnum(AlcoholConsumption) alcoholConsumption!: AlcoholConsumption;
  @IsEnum(DietType) dietType!: DietType;
}

export class OnboardingGoalsDto {
  @IsEnum(PrimaryGoal) primaryGoal!: PrimaryGoal;
  @IsEnum(GoalTimeline) timeline!: GoalTimeline;
  @IsOptional() @IsNumber() @Min(20) @Max(300) targetWeightKg?: number;
}

/** Mirrors ACC1 `OnboardingCompletePayloadDto`. */
export class OnboardingCompleteDto {
  @ValidateNested() @Type(() => PersonalInfoDto) personalInfo!: PersonalInfoDto;
  @ValidateNested() @Type(() => OnboardingHealthProfileDto) healthProfile!: OnboardingHealthProfileDto;
  @ValidateNested() @Type(() => OnboardingMedicalProfileDto) medicalProfile!: OnboardingMedicalProfileDto;
  @ValidateNested() @Type(() => OnboardingLifestyleDto) lifestyle!: OnboardingLifestyleDto;
  @ValidateNested() @Type(() => OnboardingGoalsDto) goals!: OnboardingGoalsDto;
}
