import { FamilyRelation } from '@prisma/client';
import { IsOptional, IsString, MaxLength, IsEnum } from 'class-validator';

export class CreateFamilyHistoryDto {
  @IsEnum(FamilyRelation)
  relation!: FamilyRelation;

  @IsString()
  @MaxLength(150)
  condition!: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  notes?: string;
}
