import { Type } from 'class-transformer';
import { IsDateString, IsEnum, IsNumber, IsOptional, Max, Min } from 'class-validator';
import { SleepQuality } from '@prisma/client';

/**
 * Bible API 46 — POST /sleep. Fields: Hours, Quality, Bed Time, Wake Time.
 * Nothing beyond those four is accepted.
 */
export class LogSleepDto {
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(24)
  hours!: number;

  @IsEnum(SleepQuality)
  quality!: SleepQuality;

  @IsOptional()
  @IsDateString()
  bedTime?: string;

  @IsOptional()
  @IsDateString()
  wakeTime?: string;
}
