import { IsBoolean, IsEnum, IsIn, IsString } from 'class-validator';
import { HeightUnit, WeightUnit } from '@prisma/client';

/**
 * Selectable languages are English, Hindi and Telugu — the primary languages
 * named in AI_Design §16. The future languages listed there (ta, kn, ml, mr)
 * are deliberately NOT accepted yet, matching ACC1's `LanguageCode`.
 */
export const SELECTABLE_LANGUAGE_CODES = ['en', 'hi', 'te'] as const;

export class UpdateLanguageSettingsDto {
  @IsString()
  @IsIn(SELECTABLE_LANGUAGE_CODES as unknown as string[])
  languageCode!: string;
}

export class UpdateUnitsPreferenceDto {
  @IsEnum(HeightUnit)
  heightUnit!: HeightUnit;

  @IsEnum(WeightUnit)
  weightUnit!: WeightUnit;
}

/** All six categories are required — ACC1 sends the complete object. */
export class UpdateNotificationPreferencesDto {
  @IsBoolean() mealReminder!: boolean;
  @IsBoolean() waterReminder!: boolean;
  @IsBoolean() exerciseReminder!: boolean;
  @IsBoolean() medicineReminder!: boolean;
  @IsBoolean() sleepReminder!: boolean;
  @IsBoolean() healthTips!: boolean;
}

export class UpdatePrivacyConsentDto {
  @IsBoolean()
  shareDataForResearch!: boolean;
}
