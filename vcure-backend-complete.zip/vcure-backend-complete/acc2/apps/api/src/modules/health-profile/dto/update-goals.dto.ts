import { IsEnum, IsNumber, IsOptional, Max, Min } from 'class-validator';
import { GoalTimeline, PrimaryGoal } from '@prisma/client';

/**
 * ACC1 `goalsSchema` (lib/validation/onboarding.ts) + `HealthGoalDto`.
 * Persisted on HealthProfile — no separate goals table exists in the
 * Engineering Bible's Health domain for this contract.
 */
export class UpdateGoalsDto {
  @IsOptional()
  @IsEnum(PrimaryGoal)
  primaryGoal?: PrimaryGoal;

  @IsOptional()
  @IsEnum(GoalTimeline)
  timeline?: GoalTimeline;

  @IsOptional()
  @IsNumber()
  @Min(20)
  @Max(300)
  targetWeightKg?: number;
}
