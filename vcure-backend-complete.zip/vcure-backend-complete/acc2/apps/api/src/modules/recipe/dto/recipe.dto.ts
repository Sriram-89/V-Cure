import { IsEnum, IsIn, IsOptional, IsString, MaxLength } from 'class-validator';
import { RecipeDifficulty } from '@prisma/client';
import { DIET_TAGS, RECIPE_CATEGORIES } from '../types/recipe.type';

/** ACC1 `RecipeFilters`. */
export class RecipeFiltersDto {
  @IsOptional()
  @IsIn(RECIPE_CATEGORIES as unknown as string[])
  category?: string;

  @IsOptional()
  @IsEnum(RecipeDifficulty)
  difficulty?: RecipeDifficulty;

  @IsOptional()
  @IsIn(DIET_TAGS as unknown as string[])
  dietTag?: string;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  query?: string;
}
