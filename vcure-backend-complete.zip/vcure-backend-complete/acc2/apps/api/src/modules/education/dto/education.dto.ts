import { Type } from 'class-transformer';
import { IsEnum, IsIn, IsInt, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';
import { ArticleDifficulty } from '@prisma/client';
import { EDUCATION_CATEGORIES } from '../types/education.type';

/** ACC1 `ArticleFilters`. No filter beyond these three is accepted. */
export class ArticleFiltersDto {
  @IsOptional()
  @IsIn(EDUCATION_CATEGORIES as unknown as string[])
  category?: string;

  @IsOptional()
  @IsEnum(ArticleDifficulty)
  difficulty?: ArticleDifficulty;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  query?: string;
}

export class CategoryQueryDto {
  @IsOptional()
  @IsIn(EDUCATION_CATEGORIES as unknown as string[])
  category?: string;
}

export class RequiredCategoryDto {
  @IsIn(EDUCATION_CATEGORIES as unknown as string[])
  category!: string;
}

/** ACC1 `updateProgress(articleId, percentRead)`. */
export class UpdateProgressDto {
  @Type(() => Number)
  @IsInt()
  @Min(0)
  @Max(100)
  percentRead!: number;
}
